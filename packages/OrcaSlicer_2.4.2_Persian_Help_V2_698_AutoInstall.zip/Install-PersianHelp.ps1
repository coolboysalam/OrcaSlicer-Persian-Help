﻿[CmdletBinding()]
param(
    [string]$InstallDir = 'C:\Program Files\OrcaSlicer',
    [switch]$RestoreEnglish
)
$ErrorActionPreference = 'Stop'
try {
    # Request normal Windows elevation only when the installation directory needs it.
    $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $admin) {
        $launch = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $PSCommandPath), '-InstallDir', ('"{0}"' -f $InstallDir))
        if ($RestoreEnglish) { $launch += '-RestoreEnglish' }
        $child = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $launch -Wait -PassThru
        exit $child.ExitCode
    }
    $exe = Join-Path $InstallDir 'orca-slicer.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        throw "OrcaSlicer executable not found: $exe. This package targets the classic installation, not Microsoft Store."
    }
    $installFull = [IO.Path]::GetFullPath($InstallDir).TrimEnd('\') + '\'
    # Do not close the app or discard unsaved projects.
    $running = @(Get-Process -Name 'orca-slicer' -ErrorAction SilentlyContinue | Where-Object {
        $p = $_.Path
        $p -and $p.StartsWith($installFull, [StringComparison]::OrdinalIgnoreCase)
    })
    if ($running.Count -gt 0) {
        Write-Host 'Save your work and close this OrcaSlicer instance, then return here.' -ForegroundColor Yellow
        [void](Read-Host 'Press ENTER after closing OrcaSlicer')
        $stillRunning = @(Get-Process -Name 'orca-slicer' -ErrorAction SilentlyContinue | Where-Object {
            $p = $_.Path
            $p -and $p.StartsWith($installFull, [StringComparison]::OrdinalIgnoreCase)
        })
        if ($stillRunning.Count -gt 0) { throw 'OrcaSlicer is still running. No files were changed.' }
    }
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'install-manifest.json') -Raw | ConvertFrom-Json
    if ($RestoreEnglish) {
        $source = Join-Path $PSScriptRoot 'original-backup\en\OrcaSlicer.mo'
        $expected = $manifest.original_english_sha256
    } else {
        $source = Join-Path $PSScriptRoot 'resources\i18n\en\OrcaSlicer.mo'
        $expected = $manifest.persian_help_sha256
    }
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'Package is incomplete. Extract the whole ZIP before running Install.cmd.' }
    $actual = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    if ($actual -ne $expected) { throw 'Package integrity check failed. No files were changed.' }
    $dir = Join-Path $InstallDir 'resources\i18n\en'
    if (-not (Test-Path -LiteralPath $dir -PathType Container)) { throw "Language directory not found: $dir" }
    $target = Join-Path $dir 'OrcaSlicer.mo'
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        $backup = Join-Path $dir ("OrcaSlicer.mo.before-fa-$stamp.bak")
        Copy-Item -LiteralPath $target -Destination $backup -ErrorAction Stop
        Write-Host "Backup: $backup"
    }
    $temporary = Join-Path $dir ("OrcaSlicer.mo.install-$stamp.tmp")
    try {
        Copy-Item -LiteralPath $source -Destination $temporary -ErrorAction Stop
        if ((Get-FileHash -LiteralPath $temporary -Algorithm SHA256).Hash -ne $expected) { throw 'Temporary copy verification failed.' }
        Move-Item -LiteralPath $temporary -Destination $target -Force -ErrorAction Stop
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $expected) { throw 'Installed file verification failed. Restore the backup before launching.' }
    if ($RestoreEnglish) {
        Write-Host 'Original English catalog restored successfully.' -ForegroundColor Green
    } else {
        Write-Host 'Installed: 698 Persian help descriptions. Keep the application language set to English.' -ForegroundColor Green
    }
    Write-Host "Launch this executable: $exe"
    Write-Host 'Profiles and print settings were not modified.'
    [void](Read-Host 'Press ENTER to finish')
    exit 0
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    [void](Read-Host 'Press ENTER to finish')
    exit 1
}
