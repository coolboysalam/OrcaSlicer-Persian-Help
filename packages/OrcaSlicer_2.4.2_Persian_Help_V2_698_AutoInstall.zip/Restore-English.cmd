@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-PersianHelp.ps1" -RestoreEnglish
if errorlevel 1 pause
endlocal
