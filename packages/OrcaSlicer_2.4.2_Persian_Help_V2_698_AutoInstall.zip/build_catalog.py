"""Build English UI / Persian tooltip catalog from the included source files.
Python 3 standard library only. Run from any directory.
"""
from pathlib import Path
import struct,json,gettext,re
ROOT=Path(__file__).resolve().parent

def read_mo_raw(data):
 magic,=struct.unpack_from('<I',data)
 order='<' if magic==0x950412de else '>'
 _,_,n,orig,translated,_,_=struct.unpack_from(order+'7I',data)
 result={}
 for i in range(n):
  l,o=struct.unpack_from(order+'2I',data,orig+8*i)
  m,p=struct.unpack_from(order+'2I',data,translated+8*i)
  result[data[o:o+l].decode('utf-8')]=data[p:p+m].decode('utf-8')
 return result

def encode_mo(catalog):
 pairs=sorted((k.encode('utf-8'),v.encode('utf-8')) for k,v in catalog.items())
 n=len(pairs);offset=28+16*n;ids=b'';strings=b'';it=[];st=[]
 for k,v in pairs:
  it.append((len(k),offset+len(ids)));ids+=k+b'\0'
 offset+=len(ids)
 for k,v in pairs:
  st.append((len(v),offset+len(strings)));strings+=v+b'\0'
 return struct.pack('<7I',0x950412de,0,n,28,28+8*n,0,0)+b''.join(struct.pack('<2I',*x) for x in it+st)+ids+strings

def build():
 baseline=(ROOT/'original-backup/en/OrcaSlicer.mo').read_bytes()
 source=read_mo_raw(baseline)
 translations=json.loads((ROOT/'translations-fa.json').read_text(encoding='utf-8'))
 forbidden={chr(x) for x in [0x200e,0x200f,0x202a,0x202b,0x202c,0x202d,0x202e,0x2066,0x2067,0x2068,0x2069]}
 for key,value in translations.items():
  assert key.count('\n')==value.count('\n'),key
  assert not forbidden.intersection(value),key
  # Preserve runtime substitutions. Literal percentages are not substitutions.
  pattern=r'(?<![0-9])%(?:\d+\$)?[-+#0]*(?:\d+|\*)?(?:\.(?:\d+|\*))?(?:hh|ll|[hlLjzt])?[sdiufFeEgGxXocpaAn]|%\d+%'
  assert re.findall(pattern,key)==re.findall(pattern,value),key
 catalog=dict(source);catalog.update(translations)
 catalog['']='Project-Id-Version: OrcaSlicer 2.4.2 Persian Help V2\nLanguage: en\nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nPlural-Forms: nplurals=2; plural=(n != 1);\n'
 output=ROOT/'resources/i18n/en/OrcaSlicer.mo';output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(encode_mo(catalog))
 before=gettext.GNUTranslations(__import__('io').BytesIO(baseline))._catalog
 after=gettext.GNUTranslations(output.open('rb'))._catalog
 for key,value in before.items():
  if key and key not in translations:assert after[key]==value,key
 for key,value in translations.items():assert after[key]==value,key
 for key in ['Support','Layer height','Shrinkage (XY)','Preferences','Speed','Quality','Strength']:
  assert after.get(key,key)==before.get(key,key),key
 # Editable PO including plural entries from the original English catalog.
 po=''
 for key,value in sorted(catalog.items()):
  if key in translations:po+='# AI Translated\n'
  if '\0' in key:
   singular,plural=key.split('\0',1)
   po+='msgid '+json.dumps(singular,ensure_ascii=False)+'\nmsgid_plural '+json.dumps(plural,ensure_ascii=False)+'\n'
   for i,form in enumerate(value.split('\0')):po+=f'msgstr[{i}] '+json.dumps(form,ensure_ascii=False)+'\n'
   po+='\n'
  else:po+='msgid '+json.dumps(key,ensure_ascii=False)+'\nmsgstr '+json.dumps(value,ensure_ascii=False)+'\n\n'
 (ROOT/'OrcaSlicer_en.po').write_text(po,encoding='utf-8')
 print(json.dumps({'translated_descriptions':len(translations),'English_runtime_entries_preserved':len(before)-1,'plural_runtime_entries_preserved':sum(isinstance(k,tuple) for k in before),'mo_bytes':output.stat().st_size,'status':'passed'}))

if __name__=='__main__':build()
