﻿[CmdletBinding()]
param(
    [string]$InstallDir = 'C:\Program Files\OrcaSlicer',
    [switch]$RestorePrevious
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

# V3.5: Case-sensitive translation import; no System.IO.File.Replace calls. Every replacement is preceded by a
# verified, separately retained backup. Rename failure triggers rollback.

function Full-Path([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { throw 'A required path is empty.' }
    return [System.IO.Path]::GetFullPath($Path)
}
function Sha([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
}
function Read-TranslationPairs([string]$PairsPath) {
    # PowerShell 5.1 ConvertFrom-Json merges case-distinct property names and throws.
    # This parser preserves Unicode text and compares keys with StringComparer.Ordinal.
    $translations = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal)
    $lineNo = 0
    foreach ($line in [IO.File]::ReadAllLines((Full-Path $PairsPath), [Text.Encoding]::ASCII)) {
        $lineNo++
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $columns = $line.Split([char]9)
        if ($columns.Length -ne 2) { throw "Malformed translation pair on line $lineNo." }
        try {
            $key = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($columns[0]))
            $value = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($columns[1]))
        } catch { throw "Invalid Base64 or UTF-8 translation pair on line $lineNo." }
        if ([string]::IsNullOrEmpty($key) -or [string]::IsNullOrEmpty($value)) { throw "Empty translation on line $lineNo." }
        if ($translations.ContainsKey($key)) { throw "Duplicate exact translation key on line $lineNo." }
        $translations.Add($key, $value)
    }
    return ,$translations
}

function Read-Mo([string]$Path) {
    [byte[]]$bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -lt 28) { throw 'Invalid MO file: truncated header.' }
    $magic = [BitConverter]::ToUInt32($bytes, 0)
    if ($magic -ne [Convert]::ToUInt32('950412DE', 16)) { throw 'Not a supported little-endian GNU gettext MO file.' }
    $n = [BitConverter]::ToUInt32($bytes, 8)
    $orig = [BitConverter]::ToUInt32($bytes, 12)
    $trans = [BitConverter]::ToUInt32($bytes, 16)
    if ($n -gt 200000 -or ([long]$orig + 8L*$n) -gt $bytes.Length -or ([long]$trans + 8L*$n) -gt $bytes.Length) {
        throw 'Invalid MO file: string tables out of range.'
    }
    $cat = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal)
    for ($i=0; $i -lt $n; $i++) {
        $nl = [BitConverter]::ToUInt32($bytes, [int]($orig + 8L*$i))
        $no = [BitConverter]::ToUInt32($bytes, [int]($orig + 8L*$i + 4))
        $vl = [BitConverter]::ToUInt32($bytes, [int]($trans + 8L*$i))
        $vo = [BitConverter]::ToUInt32($bytes, [int]($trans + 8L*$i + 4))
        if (([long]$no+$nl) -gt $bytes.Length -or ([long]$vo+$vl) -gt $bytes.Length) {
            throw 'Invalid MO file: string entry out of bounds.'
        }
        $key = [Text.Encoding]::UTF8.GetString($bytes, [int]$no, [int]$nl)
        $value = [Text.Encoding]::UTF8.GetString($bytes, [int]$vo, [int]$vl)
        $cat[$key] = $value
    }
    return ,$cat
}
function Write-Mo($Catalog, [string]$Path) {
    $keys = [string[]]@($Catalog.Keys)
    [Array]::Sort($keys, [StringComparer]::Ordinal)
    $count = $keys.Length
    $ids = New-Object 'System.Collections.Generic.List[byte[]]'
    $values = New-Object 'System.Collections.Generic.List[byte[]]'
    [long]$idLen = 0
    [long]$valueLen = 0
    foreach ($key in $keys) {
        [byte[]]$b = [Text.Encoding]::UTF8.GetBytes($key)
        [byte[]]$v = [Text.Encoding]::UTF8.GetBytes([string]$Catalog[$key])
        [void]$ids.Add($b); [void]$values.Add($v)
        $idLen += $b.Length+1; $valueLen += $v.Length+1
    }
    if ((28L+16L*$count+$idLen+$valueLen) -ge [uint32]::MaxValue) { throw 'MO file too large.' }
    [long]$idOffset = 28L+16L*$count
    [long]$valueOffset = $idOffset+$idLen
    $stream = [IO.File]::Open($Path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
    $w = [System.IO.BinaryWriter]::new($stream)
    try {
        $w.Write([Convert]::ToUInt32('950412DE',16))
        $w.Write([uint32]0); $w.Write([uint32]$count)
        $w.Write([uint32]28); $w.Write([uint32](28+8*$count))
        $w.Write([uint32]0); $w.Write([uint32]0)
        foreach ($b in $ids) { $w.Write([uint32]$b.Length); $w.Write([uint32]$idOffset); $idOffset += $b.Length+1 }
        foreach ($b in $values) { $w.Write([uint32]$b.Length); $w.Write([uint32]$valueOffset); $valueOffset += $b.Length+1 }
        foreach ($b in $ids) { $w.Write([byte[]]$b); $w.Write([byte]0) }
        foreach ($b in $values) { $w.Write([byte[]]$b); $w.Write([byte]0) }
    } finally { $w.Dispose() }
}
# Match source tooltip IDs despite harmless English case and line-break changes.
# This is intentionally not fuzzy translation: new meanings are never guessed.
function Normalize-TooltipKey([string]$Key) {
    if ([string]::IsNullOrWhiteSpace($Key)) { return '' }
    return ([regex]::Replace($Key, '\s+', ' ').Trim().ToLowerInvariant())
}
function Switch-MoSafely([string]$Target, [string]$Incoming, [string]$Backup, [string]$ExpectedIncomingHash, [string]$Stamp) {
    # Only renames and copies; intentionally never uses File.Replace.
    $Target = Full-Path $Target
    $Incoming = Full-Path $Incoming
    $Backup = Full-Path $Backup
    $oldHash = Sha $Target
    if ([IO.File]::Exists($Backup)) { throw "Backup already exists: $Backup" }
    if ((Sha $Incoming) -ne $ExpectedIncomingHash) { throw 'Incoming MO checksum mismatch before installation.' }
    [IO.File]::Copy($Target, $Backup, $false)
    if ((Sha $Backup) -ne $oldHash) { throw "Backup verification failed. Original unchanged: $Target" }
    $parked = Full-Path (Join-Path ([IO.Path]::GetDirectoryName($Target)) ("OrcaSlicer.mo.in-progress-v3_2-$Stamp.old"))
    if ([IO.File]::Exists($parked)) { throw 'Temporary staging filename already exists. Nothing replaced.' }
    try {
        if ((Sha $Target) -ne $oldHash) { throw 'The language file changed while preparing installation. No files replaced.' }
        [IO.File]::Move($Target, $parked)
        [IO.File]::Move($Incoming, $Target)
        if ((Sha $Target) -ne $ExpectedIncomingHash) { throw 'Installed file checksum mismatch.' }
        # Both backups remain until success. The parked old file can now be removed.
        [IO.File]::Delete($parked)
    } catch {
        $problem = $_.Exception.Message
        $rollbackFailure = $null
        try {
            if ([IO.File]::Exists($parked)) {
                if ([IO.File]::Exists($Target)) { [IO.File]::Delete($Target) }
                [IO.File]::Move($parked, $Target)
            } elseif (-not [IO.File]::Exists($Target)) {
                [IO.File]::Copy($Backup, $Target, $false)
            } elseif ((Sha $Target) -ne $oldHash) {
                [IO.File]::Copy($Backup, $Target, $true)
            }
            if ((Sha $Target) -ne $oldHash) { throw 'Rollback checksum mismatch.' }
        } catch { $rollbackFailure = $_.Exception.Message }
        if ($rollbackFailure) {
            throw "Replacement failed: $problem. AUTOMATIC ROLLBACK FAILED: $rollbackFailure. Recovery backup: $Backup"
        }
        throw "Replacement failed; original file restored. Cause: $problem. Backup: $Backup"
    }
    return $oldHash
}

try {
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        $parts = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $PSCommandPath),'-InstallDir',('"{0}"' -f $InstallDir))
        if ($RestorePrevious) { $parts += '-RestorePrevious' }
        $process = Start-Process 'powershell.exe' -Verb RunAs -ArgumentList $parts -Wait -PassThru
        exit $process.ExitCode
    }
    Write-Host ''
    Write-Host 'OrcaSlicer 2.5 Persian Help | V3.5 | 802 tooltip keys' -ForegroundColor Cyan
    Write-Host 'Prepared and maintained by: Omid Taheri' -ForegroundColor Cyan
    Write-Host 'Author: Omid Taheri | GitHub: coolboysalam' -ForegroundColor Cyan
    Write-Host 'GitHub: https://github.com/coolboysalam' -ForegroundColor Cyan
    Write-Host 'Persian documentation: README_FA.md'
    Write-Host ''
    $exe = Full-Path (Join-Path $InstallDir 'orca-slicer.exe')
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        throw "Executable not found: $exe. Only the standard Windows desktop installation is supported (not Microsoft Store)."
    }
    $dir = Full-Path (Join-Path $InstallDir 'resources\i18n\en')
    $target = Full-Path (Join-Path $dir 'OrcaSlicer.mo')
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "English catalog not found: $target" }
    $statePath = Full-Path (Join-Path $dir 'PersianHelp-V3-state.json')
    $stamp = (Get-Date -Format 'yyyyMMdd_HHmmss_fff')

    $root = (Full-Path $InstallDir).TrimEnd('\') + '\'
    $running = @(Get-Process -Name 'orca-slicer' -ErrorAction SilentlyContinue | Where-Object {
        try { $_.Path -and $_.Path.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) } catch { $false }
    })
    if ($running.Count -gt 0) {
        Write-Host 'Save your project and close OrcaSlicer. The program will not be terminated.' -ForegroundColor Yellow
        [void](Read-Host 'Press ENTER after closing OrcaSlicer')
        $running = @(Get-Process -Name 'orca-slicer' -ErrorAction SilentlyContinue | Where-Object {
            try { $_.Path -and $_.Path.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) } catch { $false }
        })
        if ($running.Count -gt 0) { throw 'OrcaSlicer is still open. No changes made.' }
    }

    if ($RestorePrevious) {
        if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'No successful V3 installation record was found. Nothing changed.' }
        $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $originalBackup = Full-Path (Join-Path $dir ([string]$state.backup_filename))
        if (-not (Test-Path -LiteralPath $originalBackup -PathType Leaf)) { throw "Backup missing: $originalBackup" }
        if ((Sha $originalBackup) -ne [string]$state.backup_sha256) { throw 'Saved backup hash does not match the install record.' }
        $undoBackup = Full-Path (Join-Path $dir ("OrcaSlicer.mo.before-v3_2-restore-$stamp.bak"))
        $restoreIncoming = Full-Path (Join-Path $dir ("OrcaSlicer.mo.v3_2-restore-$stamp.tmp"))
        try {
            [IO.File]::Copy($originalBackup, $restoreIncoming, $false)
            [void](Switch-MoSafely $target $restoreIncoming $undoBackup ([string]$state.backup_sha256) $stamp)
        } finally { if ([IO.File]::Exists($restoreIncoming)) { [IO.File]::Delete($restoreIncoming) } }
        if ((Sha $target) -ne [string]$state.backup_sha256) { throw "Restore verification failed. Backup: $originalBackup" }
        # Keep all .bak files for further recovery. State is archived, not deleted.
        $archivedState = Full-Path (Join-Path $dir ("PersianHelp-V3-state.restored-$stamp.json"))
        [IO.File]::Move($statePath, $archivedState)
        Write-Host 'RESTORE SUCCESSFUL: exact language file from before V3 is active.' -ForegroundColor Green
        Write-Host "Restored from: $originalBackup"
        Write-Host "Previously active language file backed up: $undoBackup"
    } else {
        $version = (((Get-Item -LiteralPath $exe).VersionInfo.ProductVersion) + ' ' + ((Get-Item -LiteralPath $exe).VersionInfo.FileVersion)).Trim()
        if ($version -and ($version -notmatch '2[.]5[.]')) { throw "Expected OrcaSlicer 2.5.x; executable reports '$version'. Nothing changed." }
        if (-not $version) {
            Write-Host 'The executable has no Windows file version metadata.' -ForegroundColor Yellow
            Write-Host 'Check OrcaSlicer > Help > About before continuing.' -ForegroundColor Yellow
            $confirm = Read-Host 'If About says 2.5.x, type 2.5 to continue (otherwise cancel)'
            if ($confirm.Trim() -ne '2.5') { throw 'OrcaSlicer version was not confirmed. Nothing changed.' }
        }
        $manifestPath = Join-Path $PSScriptRoot 'install-manifest.json'
        $translationsPath = Join-Path $PSScriptRoot 'translations-fa.json'
        $pairsPath = Join-Path $PSScriptRoot 'translations-fa.pairs.tsv'
        if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf) -or -not (Test-Path -LiteralPath $translationsPath -PathType Leaf) -or -not (Test-Path -LiteralPath $pairsPath -PathType Leaf)) {
            throw 'Required files missing. Extract the entire ZIP before installation.'
        }
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ((Sha $translationsPath) -ne [string]$manifest.translations_sha256) { throw 'Translation JSON hash mismatch; no changes made.' }
        if ((Sha $pairsPath) -ne [string]$manifest.translation_pairs_sha256) { throw 'Translation pairs hash mismatch; no changes made.' }
        $translations = Read-TranslationPairs $pairsPath
        if ($translations.Count -ne [int]$manifest.translated_descriptions) { throw 'Translation pair count mismatch; no changes made.' }
        $catalog = Read-Mo $target
        $priorSha = Sha $target
        if (Test-Path -LiteralPath $statePath -PathType Leaf) {
            $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($priorSha -eq [string]$state.installed_sha256 -and ([string]$state.installer -eq 'V3.5') -and ([string]$state.translation_data_sha256 -eq [string]$manifest.translations_sha256)) {
                Write-Host 'V3.5 is already installed and verified. No changes necessary.' -ForegroundColor Green
                [void](Read-Host 'Press ENTER to finish'); exit 0
            }
        }
        $count = 0
        $exactExisting = 0
        $missingInExisting = 0
        foreach ($entry in $translations.GetEnumerator()) {
            if ($catalog.ContainsKey($entry.Key)) { $exactExisting++ } else { $missingInExisting++ }
            $catalog[$entry.Key] = $entry.Value
            $count++
        }
        if ($count -ne [int]$manifest.translated_descriptions) { throw "Translation count mismatch: $count. Nothing changed." }
        $incoming = Full-Path (Join-Path $dir ("OrcaSlicer.mo.v3_2-$stamp.tmp"))
        $backup = Full-Path (Join-Path $dir ("OrcaSlicer.mo.before-fa-v3_2-$stamp.bak"))
        $pendingState = Full-Path (Join-Path $dir ("PersianHelp-V3-state.pending-$stamp.json"))
        $oldStateArchive = Full-Path (Join-Path $dir ("PersianHelp-V3-state.pre-v3_2-$stamp.json"))
        $switched = $false
        try {
            Write-Mo $catalog $incoming
            $verify = Read-Mo $incoming
            foreach ($entry in $translations.GetEnumerator()) {
                if ($verify[[string]$entry.Key] -cne [string]$entry.Value) { throw 'New MO translation verification failed.' }
            }
            $installedSha = Sha $incoming
            $newState = [ordered]@{ translation_data_sha256=[string]$manifest.translations_sha256; target_version='2.5.x'; backup_filename=[IO.Path]::GetFileName($backup); backup_sha256=$priorSha; installed_sha256=$installedSha; timestamp=$stamp; translated_descriptions=$count; installer='V3.5' }
            $newState | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $pendingState -Encoding UTF8
            [void](Switch-MoSafely $target $incoming $backup $installedSha $stamp)
            $switched = $true
            if (Test-Path -LiteralPath $statePath -PathType Leaf) { [IO.File]::Copy($statePath, $oldStateArchive, $false) }
            [IO.File]::Copy($pendingState, $statePath, $true)
            if ((Sha $target) -ne $installedSha) { throw 'Installed catalog SHA256 mismatch after state creation.' }
        } catch {
            $err = $_.Exception.Message
            if ($switched) {
                try {
                    [IO.File]::Copy($backup, $target, $true)
                    if ((Sha $target) -ne $priorSha) { throw 'Rollback file hash mismatch.' }
                    if ([IO.File]::Exists($oldStateArchive)) { [IO.File]::Copy($oldStateArchive, $statePath, $true) }
                    elseif ([IO.File]::Exists($statePath)) { [IO.File]::Delete($statePath) }
                    throw "Install aborted; prior language file restored. Cause: $err"
                } catch {
                    if ($_.Exception.Message.StartsWith('Install aborted;')) { throw $_ }
                    throw "Install aborted: $err. Automatic rollback could not be confirmed. Recovery backup: $backup. Rollback error: $($_.Exception.Message)"
                }
            }
            throw
        } finally {
            if ([IO.File]::Exists($incoming)) { [IO.File]::Delete($incoming) }
            if ([IO.File]::Exists($pendingState)) { [IO.File]::Delete($pendingState) }
        }
        Write-Host "SUCCESS: V3.5 installed. $count Persian help translation keys." -ForegroundColor Green
        Write-Host "Existing catalog keys matched exactly: $exactExisting"
        Write-Host "Source translation keys missing from installed catalog: $missingInExisting"
        Write-Host "Backup (kept): $backup"
        Write-Host 'UI labels remain English. Set application language to English.'
        Write-Host 'Printer, filament, process presets, and user profiles were not changed.'
    }
    Write-Host "Launch OrcaSlicer: $exe"
    [void](Read-Host 'Press ENTER to finish')
    exit 0
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Do not delete any .bak files. If necessary, send us the entire error output.' -ForegroundColor Yellow
    [void](Read-Host 'Press ENTER to finish')
    exit 1
}
