@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-PersianHelp.ps1" -RestorePrevious
exit /b %errorlevel%
