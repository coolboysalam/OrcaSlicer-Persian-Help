#!/usr/bin/env python3
r"""OrcaSlicer 2.5.0 PrintConfig tooltip audit. READ ONLY.
Run: py -3 audit_tooltips_v25.py --mo "C:\Program Files\OrcaSlicer\resources\i18n\en\OrcaSlicer.mo"
Uses an official pinned GitHub source unless --source SOURCE_CPP is supplied.
Writes TSV/JSON with English and Persian side by side; does not change OrcaSlicer.
"""
import argparse,csv,io,json,pathlib,re,urllib.request,sys,collections,hashlib,struct
SOURCE_URL='https://raw.githubusercontent.com/OrcaSlicer/OrcaSlicer/v2.5.0/src/libslic3r/PrintConfig.cpp'
ROOT=pathlib.Path(__file__).resolve().parent

def unpack_mo(path):
    data=path.read_bytes(); magic=struct.unpack_from('<I',data)[0]
    if magic not in (0x950412de,0xde120495):raise ValueError('Not a valid GNU MO file')
    e='<' if magic==0x950412de else '>'
    rev,n,orig,trans,_,_=struct.unpack_from(e+'6I',data,4)
    if n>500000 or orig+8*n>len(data) or trans+8*n>len(data):raise ValueError('MO index outside file')
    out={}
    for i in range(n):
        ol,oo=struct.unpack_from(e+'2I',data,orig+8*i);tl,to=struct.unpack_from(e+'2I',data,trans+8*i)
        if oo+ol>len(data) or to+tl>len(data):raise ValueError('Corrupt MO entry')
        out[data[oo:oo+ol].decode('utf8')]=data[to:to+tl].decode('utf8')
    return out

def extract(source):
    # The upstream code contains concatenated C++ string literals in L("...").
    s='\n'.join(line for line in source.splitlines() if not line.strip().startswith('//'))
    pattern=re.compile(r'def->tooltip\s*=\s*L\(\s*((?:"(?:\\.|[^"\\])*"\s*)+)\)',re.S)
    literal=re.compile(r'"(?:\\.|[^"\\])*"')
    out=[]; seen=set()
    for match in pattern.finditer(s):
        parts=literal.findall(match.group(1)); chunks=[]
        for p in parts:
            try:chunks.append(json.loads(p))
            except json.JSONDecodeError:
                # Mimic C++ escaped apostrophes. JSON itself does not permit \'
                p=p.replace("\\'", "'")
                chunks.append(json.loads(p))
        text=''.join(chunks)
        if text.strip() and text not in seen:out.append(text);seen.add(text)
    return out

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--mo',type=pathlib.Path,help='Installed English catalog; default: package fallback MO')
    ap.add_argument('--source',type=pathlib.Path,help='Downloaded v2.5.0 PrintConfig.cpp; otherwise fetch official upstream')
    ap.add_argument('--output',type=pathlib.Path,default=pathlib.Path('translation-audit-v25'))
    args=ap.parse_args()
    path=args.mo or ROOT/'resources/i18n/en/OrcaSlicer.mo'
    if not path.is_file():ap.error('MO file not found: '+str(path))
    catalog=unpack_mo(path)
    package_translations=json.loads((ROOT/'translations-fa.json').read_text(encoding='utf8'))
    if args.source:source=args.source.read_text(encoding='utf8')
    else:
        try:
            with urllib.request.urlopen(SOURCE_URL,timeout=25) as response:source=response.read().decode('utf8')
        except Exception as e:
            print('Could not retrieve the exact upstream source: '+str(e),file=sys.stderr)
            print('Download '+SOURCE_URL+' and use --source path-to-PrintConfig.cpp',file=sys.stderr)
            return 2
    keys=extract(source)
    if len(keys)<750:raise ValueError('Incomplete source parsing: '+str(len(keys))+' keys; no report written')
    records=[]
    for key in keys:
        actual=catalog.get(key,'')
        package=package_translations.get(key,'')
        # Do not treat a Persian translation with a nonmatching key as covering this message.
        translated=bool(re.search('[\u0600-\u06ff]',actual))
        status='translated_in_MO' if translated else ('translation_available_not_installed' if package else 'untranslated')
        records.append({'status':status,'english_msgid':key,'installed_msgstr':actual,'package_persian':package})
    folder=args.output;folder.mkdir(parents=True,exist_ok=True)
    with (folder/'all_tooltips.tsv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=records[0].keys(),delimiter='\t');writer.writeheader();writer.writerows(records)
    with (folder/'untranslated_tooltips.tsv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=records[0].keys(),delimiter='\t');writer.writeheader();writer.writerows(x for x in records if x['status']!='translated_in_MO')
    summary=dict(collection='PrintConfig.cpp only',target_tag='v2.5.0',source_url=SOURCE_URL,source_sha256=hashlib.sha256(source.encode('utf8')).hexdigest(),mo_path=str(path),total=len(records),counts=dict(collections.Counter(x['status'] for x in records)))
    (folder/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2));print('Report:',folder.resolve());return 0
if __name__=='__main__':sys.exit(main())
