@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Install-PersianHelp.ps1" (
    echo ERROR: Install-PersianHelp.ps1 is missing.
    echo Please extract the COMPLETE ZIP to a folder, then run this file.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-PersianHelp.ps1"
set "STATUS=%ERRORLEVEL%"
exit /b %STATUS%
