@echo off
cd /d "%~dp0"
py -3 "%~dp0audit_tooltips_v25.py" --mo "C:\Program Files\OrcaSlicer\resources\i18n\en\OrcaSlicer.mo"
pause
